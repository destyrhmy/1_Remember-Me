package com.example.rememberme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.text.ParseException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private isiAdapter IsiAdapter;
    private ArrayList<isi_konten> name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            initializationData();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        recyclerView = findViewById(R.id.recyleview);
        IsiAdapter = new isiAdapter(name);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(IsiAdapter);

    }

    private void initializationData() throws ParseException {
        name = new ArrayList<>();

        name.add(new isi_konten("Deadline PPL1"));
        name.add(new isi_konten("Bikin class diagram"));
        name.add(new isi_konten("Kuhim"));
        name.add(new isi_konten("Libur"));
    }
}
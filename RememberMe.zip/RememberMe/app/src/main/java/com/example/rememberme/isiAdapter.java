package com.example.rememberme;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class isiAdapter extends RecyclerView.Adapter<isiAdapter.ViewHolder> {
    private ArrayList<isi_konten> name;

    public isiAdapter(ArrayList<isi_konten> name) {
        this.name=name;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = (View) LayoutInflater.from(parent.getContext()).inflate(R.layout.konten, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull isiAdapter.ViewHolder holder, int position) {
        isi_konten isiKonten = name.get(position);

        holder.name.setText(isi_konten.getName());

    }

    @Override
    public int getItemCount() {
        if (name != null){
            return name.size();
        } else{
            return 0;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final TextView name;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            name = view.findViewById(R.id.name);
        }
    }
}

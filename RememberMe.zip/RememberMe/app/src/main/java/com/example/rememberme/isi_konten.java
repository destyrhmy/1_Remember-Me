package com.example.rememberme;

public class isi_konten {
    private static String name;

    public isi_konten(String name) {
        this.name = name;
    }

    public static String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
